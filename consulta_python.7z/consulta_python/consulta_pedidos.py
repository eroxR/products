import mysql.connector
from mysql.connector import Error

def crear_conexion():
    """Crea una conexión a la base de datos MySQL."""
    try:
        conexion = mysql.connector.connect(
            host='localhost',
            database='productos_labtica',
            user='root',
            password='Erox'
        )
        if conexion.is_connected():
            print("Conexión a la base de datos MySQL exitosa")
            return conexion
    except Error as e:
        print(f"Error al conectar a MySQL: {e}")
        return None

def ejecutar_consulta(conexion, consulta):
    """Ejecuta una consulta SQL y retorna los resultados."""
    cursor = conexion.cursor()
    try:
        cursor.execute(consulta)
        resultados = cursor.fetchall()
        return resultados
    except Error as e:
        print(f"Error al ejecutar la consulta: {e}")
        return None
    finally:
        cursor.close()

def cerrar_conexion(conexion):
    """Cierra la conexión a la base de datos."""
    if conexion.is_connected():
        conexion.close()
        print("Conexión a MySQL cerrada")

if __name__ == '__main__':
    # Establecer conexión
    conn = crear_conexion()

    if conn:
        # 1. Consulta para el Promedio del valor total de pedido
        consulta_promedio = """
        SELECT AVG(total_pedido) AS promedio_total_pedido
        FROM (
            SELECT dp.pedido_id, SUM(p.precio * dp.cantidad) AS total_pedido
            FROM detalles_pedidos dp
            JOIN productos p ON dp.producto_id = p.id
            GROUP BY dp.pedido_id
        ) AS totales_por_pedido;
        """
        
        print("\n--- Calculando el Promedio del Valor Total de Pedido ---")
        resultados_promedio = ejecutar_consulta(conn, consulta_promedio)
        
        if resultados_promedio:
            for fila in resultados_promedio:
                print(f"El promedio del valor total de los pedidos es: {fila[0]:.2f}")

        # 2. Consulta para el Top 3 de clientes por valor total
        consulta_top_clientes = """
        SELECT c.nombre, SUM(p.precio * dp.cantidad) AS total_gastado
        FROM clientes c
        JOIN pedidos pe ON c.id = pe.cliente_id
        JOIN detalles_pedidos dp ON pe.id = dp.pedido_id
        JOIN productos p ON dp.producto_id = p.id
        GROUP BY c.nombre
        ORDER BY total_gastado DESC
        LIMIT 3;
        """
        
        print("\n--- Top 3 Clientes por Valor Total Gastado ---")
        resultados_top_clientes = ejecutar_consulta(conn, consulta_top_clientes)
        
        if resultados_top_clientes:
            print("Posición | Cliente | Total Gastado")
            print("------------------------------------")
            for i, fila in enumerate(resultados_top_clientes, 1):
                print(f"{i}. | {fila[0]} | {fila[1]:.2f}")
        
        # Cerrar la conexión
        cerrar_conexion(conn)